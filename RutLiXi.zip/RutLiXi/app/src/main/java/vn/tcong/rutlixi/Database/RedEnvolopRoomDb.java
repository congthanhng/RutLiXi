package vn.tcong.rutlixi.Database;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import vn.tcong.rutlixi.entity.RedEnvolopEntity;

@Database(entities = {RedEnvolopEntity.class}, version = 1)
public abstract class RedEnvolopRoomDb extends RoomDatabase {
    public abstract RedEnvolopEntity redEnvolopEntity();


    public static final String DB_NAME = "redEnvolop-db";

    private static RedEnvolopRoomDb sRedEnvolopRoomDb;
    public static RedEnvolopRoomDb getInstance(Context context){
        if(sRedEnvolopRoomDb == null){
            sRedEnvolopRoomDb = Room.databaseBuilder(context,RedEnvolopRoomDb.class,DB_NAME)
                    .fallbackToDestructiveMigration()
                    .build();
        }
        return sRedEnvolopRoomDb;
    }
}
